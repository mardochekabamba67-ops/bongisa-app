-- Base de données de production : à exécuter dans Supabase après création du projet.
create extension if not exists pgcrypto;
create type public.user_role as enum ('client','artisan','admin');
create type public.booking_status as enum ('requested','quoted','accepted','in_progress','completed','cancelled');
create type public.payment_status as enum ('pending','paid','failed','refunded','released');
create table public.profiles (id uuid primary key references auth.users(id) on delete cascade, full_name text not null, phone text unique not null, role public.user_role not null default 'client', created_at timestamptz default now());
create table public.artisans (id uuid primary key default gen_random_uuid(), user_id uuid references public.profiles(id) on delete cascade, display_name text not null, trade text not null, description text, commune text, verified boolean not null default false, active boolean not null default true, created_at timestamptz default now());
create table public.bookings (id uuid primary key default gen_random_uuid(), client_id uuid references public.profiles(id), artisan_id uuid references public.artisans(id), description text not null, address_area text not null, status public.booking_status not null default 'requested', quote_amount numeric(12,2), currency text not null default 'USD' check(currency in ('USD','CDF')), created_at timestamptz default now());
create table public.payments (id uuid primary key default gen_random_uuid(), booking_id uuid not null references public.bookings(id), payer_id uuid references public.profiles(id), provider text not null check(provider = 'orange_money'), provider_reference text unique, amount numeric(12,2) not null, currency text not null check(currency in ('USD','CDF')), status public.payment_status not null default 'pending', created_at timestamptz default now());
create table public.reviews (id uuid primary key default gen_random_uuid(), booking_id uuid unique references public.bookings(id), client_id uuid references public.profiles(id), artisan_id uuid references public.artisans(id), rating int not null check(rating between 1 and 5), comment text, created_at timestamptz default now());
alter table public.profiles enable row level security; alter table public.artisans enable row level security; alter table public.bookings enable row level security; alter table public.payments enable row level security; alter table public.reviews enable row level security;
create policy "profiles read own" on public.profiles for select using (auth.uid()=id);
create policy "profiles update own" on public.profiles for update using (auth.uid()=id);
create policy "artisans public active" on public.artisans for select using (active=true);
create policy "bookings client read own" on public.bookings for select using (auth.uid()=client_id);
create policy "bookings client create" on public.bookings for insert with check (auth.uid()=client_id);
create policy "payments payer read own" on public.payments for select using (auth.uid()=payer_id);
