import 'dotenv/config';
import express from 'express'; import helmet from 'helmet'; import cors from 'cors'; import {z} from 'zod';
const app=express(); app.use(helmet()); app.use(cors({origin:process.env.APP_ORIGIN?.split(',')||false})); app.use(express.json());
app.get('/health',(_,res)=>res.json({ok:true,service:'Bongisa API',payments:'not_configured'}));
const paymentSchema=z.object({provider:z.literal('orange_money'),amount:z.number().positive(),currency:z.enum(['USD','CDF']),phone:z.string().min(8),bookingId:z.string().min(1)});
app.post('/api/payments/checkout',async(req,res)=>{const parsed=paymentSchema.safeParse(req.body);if(!parsed.success)return res.status(400).json({error:'Données de paiement invalides',details:parsed.error.flatten()});
// Intégration volontairement bloquée tant que les accès marchands et contrats API ne sont pas fournis.
const provider=parsed.data.provider;const configured=Boolean(process.env.ORANGE_MONEY_MERCHANT_ID&&process.env.ORANGE_MONEY_API_KEY);
if(!configured)return res.status(503).json({error:`${provider} n'est pas encore configuré. Aucun paiement n'a été initié.`,code:'PROVIDER_NOT_CONFIGURED'});
return res.status(501).json({error:'Adaptateur marchand à finaliser avec la documentation et les identifiants officiels du fournisseur.',code:'ADAPTER_PENDING'});
});
app.post('/api/payments/webhook/:provider',(req,res)=>{res.status(501).json({error:'Webhook à valider et sécuriser avec les spécifications officielles du fournisseur.'})});
const port=process.env.PORT||4242;app.listen(port,()=>console.log(`Bongisa API sur http://localhost:${port}`));
