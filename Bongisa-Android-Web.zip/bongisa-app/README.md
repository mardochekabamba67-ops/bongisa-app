# Bongisa — base de lancement Android et Web

Cette livraison contient une application web progressive (PWA) responsive et la configuration pour l'emballer en application Android avec Capacitor.

## Fonctionnalités
- Interface mobile et ordinateur, recherche et filtres par métiers.
- Profils artisans d'exemple clairement marqués non vérifiés.
- Demandes de devis et historique local sur le même appareil.
- Profil local client/artisan.
- Paiement exclusivement par Orange Money personnel, avec vérification manuelle.
- Installation PWA depuis Chrome Android après publication HTTPS.
- Configuration Capacitor pour générer un projet Android natif.

## Tester
1. Installer Node.js 20+.
2. Dans ce dossier, lancer `npm install`.
3. Lancer `npm run dev`.
4. Générer les fichiers web avec `npm run build`.

## Publication Web et Android
1. Publier le dossier `dist` sur un hébergeur HTTPS (Netlify ou Vercel, configurations fournies).
2. Après publication, ouvrir le lien dans Chrome Android et choisir « Installer l'application » / « Ajouter à l'écran d'accueil ».
3. Pour produire un APK natif : `npx cap add android`, puis `npm run build`, `npx cap sync android`, puis `npx cap open android`. La compilation APK se fait dans Android Studio avec le SDK Android.

## À terminer avant exploitation réelle multi-utilisateurs
- Compte et autorisation sur un hébergeur pour publier le site et obtenir son URL publique.
- Backend partagé (ex. Supabase), authentification sécurisée et règles d'accès. Les comptes et demandes sont actuellement locaux à l'appareil.
- Artisans réels recrutés et contrôlés : les profils affichés sont des exemples.
- Numéro Orange Money personnel du bénéficiaire et consignes de paiement validées.
- Pour le compte personnel, le client effectue le transfert après acceptation du devis et fournit la référence. L'équipe Bongisa vérifie manuellement le transfert. Aucun paiement automatique, aucune API Orange et aucun séquestre ne sont activés.

Ne demandez jamais le code PIN Orange Money. Ne prétendez pas qu'un paiement est reçu avant vérification effective.
